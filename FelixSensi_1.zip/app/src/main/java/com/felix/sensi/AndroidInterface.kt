package com.felix.sensi

import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import rikka.shizuku.Shizuku

class AndroidInterface(private val webView: WebView) {

    private val mainHandler = Handler(Looper.getMainLooper())

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == REQUEST_CODE) {
            Shizuku.removeRequestPermissionResultListener(permissionListener)
            notifyJs(grantResult == PackageManager.PERMISSION_GRANTED)
        }
    }

    /** Chạy lệnh shell dưới quyền Shizuku (uid 2000). Gọi từ background thread của WebView. */
    @JavascriptInterface
    fun runShellCommand(cmd: String): String {
        return try {
            val method = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            method.isAccessible = true
            val process = method.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process

            val stdout = process.inputStream.bufferedReader().readText()
            val stderr = process.errorStream.bufferedReader().readText()
            val exit = process.waitFor()

            if (exit == 0) stdout.ifBlank { "OK" }
            else throw RuntimeException("exit=$exit ${stderr.trim()}")
        } catch (e: Exception) {
            throw RuntimeException(e.message ?: "Shell error")
        }
    }

    @JavascriptInterface
    fun requestShizukuPermission() {
        mainHandler.post {
            if (!Shizuku.pingBinder()) {
                notifyJs(false)
                return@post
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                notifyJs(true)
                return@post
            }
            Shizuku.addRequestPermissionResultListener(permissionListener)
            Shizuku.requestPermission(REQUEST_CODE)
        }
    }

    private fun notifyJs(granted: Boolean) {
        webView.post {
            webView.evaluateJavascript("window.onShizukuResult($granted)", null)
        }
    }

    companion object {
        const val REQUEST_CODE = 1001
    }
}
