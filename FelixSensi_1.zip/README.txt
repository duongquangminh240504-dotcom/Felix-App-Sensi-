Felix Sensi - Android WebView + Shizuku

Cau truc:
app/src/main/assets/index.html
app/src/main/java/com/felix/sensi/MainActivity.kt
app/src/main/java/com/felix/sensi/AndroidInterface.kt
app/src/main/AndroidManifest.xml
app/build.gradle.kts

Cach dung:
1. Tao project Android (Empty Views Activity hoac No Activity), package com.felix.sensi.
2. Thay cac file tuong ung bang cac file trong thu muc nay.
3. Them vao settings.gradle.kts/build.gradle.kts cap goc: plugin com.android.application
   va org.jetbrains.kotlin.android, va repositories google() + mavenCentral().
4. Build APK, cai len may, cai Shizuku va bat no (Wireless Debugging hoac ADB).
5. Mo app, bam CAP QUYEN SHIZUKU, sau do bam KICH HOAT TOI UU DO NHAY.
